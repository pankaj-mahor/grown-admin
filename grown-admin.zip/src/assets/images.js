import logo from "./logo.svg";
import logoV from "./logo_v.png";
import logoWhite from "./logoWhite.png";
import headerImage from "./headerImage.jpg";
import merchants from "./merchants.jpg";
import plants from "./plants.jpg";
import pots from "./pots.jpg";
import service from "./service.jpg";
import loginBg from "./login_bg.png";
import plant from "./plant.png";
import enhance from "./enhance.png";
import learnmore from "./learnmore.png";
import aboutHead from "./aboutHead.png";
export {
	logo,
	headerImage,
	merchants,
	loginBg,
	plants,
	pots,
	service,
	logoV,
	plant,
	logoWhite,
	enhance,
	learnmore,
	aboutHead,
};
