import React from 'react'

const TextError = props => <div className="errorMsg">{props.children}</div>

export default TextError
